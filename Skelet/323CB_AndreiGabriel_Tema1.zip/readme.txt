Tema 1 - MN 2022
Andrei Gabriel 323CB

Task1 - Iterative

	Pentru aceasta functie se foloseste un vector in care se citesc datele din fisierul cu numele dat;
	Se construieste matricea de adiacenta A si matricea stochastica M;
	La final, se aplica algoritmul descris in enunt.

Task2 - Algebraic

	Asemanator cu taskul 1 se prelucreaza datele;
	Aplic algoritmul din enunt si apelez functia de inversare a matricei (implementat cu algoritmul Gram-Schmidt);	
	
Task3 - Apartenenta si PageRank
 	In functia Apartenenta se calculeaza valoarea functiei membru in punctul x in functie de cele 3 cazuri. 
	In functia PageRank apelez Iterative si Apartenenta si le afisez in fisierul nume.out.
	Creez o matrice 'M' si folosesc 3 coloane: prima coloana are valorile 1:N, a doua coloana are ca valori indicii PageRank-ului, in functie de clasament,
 iar ultima coloana reprezinta clasamentul(valorile intoarse de functia Apartenenta). Afisez si matricea in acelasi fisier nume.out.
